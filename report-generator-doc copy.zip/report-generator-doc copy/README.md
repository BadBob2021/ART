# Reporting Platform Documentation

This repository contains DITA-based documentation for the Reporting Platform product.

(Updates: Randy Clark, 30 August 2018)

The directory structure is like this:

   report-generator-doc/
      |
      |
      src/
         |
         |
         en/ (and maybe folders for other languages, in time to come)
           |   |
           |   |
           |   The bookmap goes _HERE_.
           |   (Thus far, there is only one doc for this product.)
           |
           |
           topics/
           |   |
           |   |
           |   All topics and chapter-level ditamaps go here. (1)
           |
           |
           assets/
              |
              |
              images/
                 |
                 |
                 All graphics go here. (2)
                 (At present these are all .PNG files.)


1) Naming convention:
   Use these filename prefixes:
   
   m_       for a map
   c_       for a concept
   r_       for a reference
   t_       for a task
   
   
 2) Naming convention:
    Just use rp_ as a filename prefix.
